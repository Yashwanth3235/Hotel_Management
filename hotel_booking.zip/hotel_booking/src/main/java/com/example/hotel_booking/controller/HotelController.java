package com.example.hotel_booking.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.example.hotel_booking.model.HotelModel;
import com.example.hotel_booking.repository.HotelRepository;
import com.example.hotel_booking.service.HotelService;

@RestController
@RequestMapping("/api/hotels")
@CrossOrigin(origins = "http://localhost:3000")
public class HotelController {

	@Autowired
	private HotelService hotelService;

	@Autowired
	private HotelRepository hotelRepository;

	/**
	 * Add a new hotel.
	 *
	 * @param hotel the hotel object
	 * @return the saved hotel
	 */
	@PostMapping
	public ResponseEntity<HotelModel> addHotel(@RequestBody HotelModel hotel) {
		HotelModel savedHotel = hotelService.saveHotel(hotel);
		return ResponseEntity.ok(savedHotel);
	}

	/**
	 * Get all hotels.
	 *
	 * @return the list of hotels
	 */
	@GetMapping
	public ResponseEntity<List<HotelModel>> getAllHotels() {
		List<HotelModel> hotels = hotelService.getAllHotels();
		return ResponseEntity.ok(hotels);
	}

	/**
	 * Get a hotel by its ID.
	 *
	 * @param id the hotel ID
	 * @return the hotel if found, else 404 response
	 */
    // Get hotels by location
    @GetMapping("/by-location")
    public ResponseEntity<List<HotelModel>> getHotelsByLocation(@RequestParam String location) {
        return ResponseEntity.ok(hotelService.getHotelsByLocation(location));
    }

    // Get distinct locations
    @GetMapping("/locations")
    public ResponseEntity<List<String>> getDistinctLocations() {
        return ResponseEntity.ok(hotelService.getDistinctLocations());
    }
	// Endpoint to fetch hotels by location
//	@GetMapping("/hotels")
//	public List<HotelModel> getHotelsByLocation(@RequestParam String location) {
//		return hotelRepository.findByLocation(location);
//	}

	@GetMapping("/{id}")
	public ResponseEntity<HotelModel> getHotelById(@PathVariable Long id) {
		Optional<HotelModel> hotel = hotelService.getHotelById(id);
		return hotel.map(ResponseEntity::ok).orElse(ResponseEntity.status(404).body(null));
	}

	@PutMapping("/{id}")
	public ResponseEntity<HotelModel> updateHotel(@PathVariable Long id, @RequestBody HotelModel updatedHotel) {
		Optional<HotelModel> existingHotel = hotelRepository.findById(id);
		if (existingHotel.isPresent()) {
			HotelModel hotel = existingHotel.get();
			hotel.setHotelName(updatedHotel.getHotelName());
			hotel.setLocation(updatedHotel.getLocation());
			hotel.setEmail(updatedHotel.getEmail());
			hotel.setPrice(updatedHotel.getPrice());
			hotel.setTotalRooms(updatedHotel.getTotalRooms());
			hotel.setDescription(updatedHotel.getDescription());
			hotel.setStreet(updatedHotel.getStreet());
			hotel.setPinCode(updatedHotel.getPinCode());
			hotelRepository.save(hotel);
			return ResponseEntity.ok(hotel);
		} else {
			return ResponseEntity.notFound().build();
		}
	}

	/**
	 * Delete a hotel by its ID.
	 *
	 * @param id the hotel ID
	 * @return success or failure message
	 */
	@DeleteMapping("/{id}")
	public ResponseEntity<String> deleteHotel(@PathVariable Long id) {
		boolean isDeleted = hotelService.deleteHotelById(id);
		if (isDeleted) {
//            hotelService.reorderHotels(); // Reorder hotels after deletion
			return ResponseEntity.ok("Hotel deleted successfully");
		} else {
			return ResponseEntity.status(404).body("Hotel not found");
		}
	}

	// Endpoint to fetch distinct locations
//	@GetMapping("/locations")
//	public List<String> getLocations() {
//		return hotelRepository.findDistinctLocations();
//	}
}
